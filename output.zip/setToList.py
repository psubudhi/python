# Example set
my_set = {1, 2, 3, 4, 5}

# Convert set to list
my_list = list(my_set)

# Print the list
print(my_list)